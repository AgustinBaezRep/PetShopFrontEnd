'use strict';

app.controller('HomeController', function(){

var vm = this;

console.log('Hola mundo');

})